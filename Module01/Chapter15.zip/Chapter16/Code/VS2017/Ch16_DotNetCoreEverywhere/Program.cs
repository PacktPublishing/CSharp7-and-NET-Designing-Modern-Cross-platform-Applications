﻿using System;

namespace Ch16_DotNetCoreEverywhere
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I can run everywhere!");
        }
    }
}