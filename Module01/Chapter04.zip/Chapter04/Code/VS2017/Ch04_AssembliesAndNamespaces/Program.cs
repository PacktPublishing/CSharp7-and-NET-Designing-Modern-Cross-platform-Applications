﻿using System.Xml.Linq;

class Program
{
    static void Main(string[] args)
    {
        var doc = new XDocument();
    }
}