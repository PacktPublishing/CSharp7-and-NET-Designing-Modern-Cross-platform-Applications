﻿using System;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello Mac!");
            try
            {
            Console.BufferHeight=120;
            }
            catch(PlatformNotSupportedException)
            {
                Console.WriteLine("not supported");
            }
        }
    }
}
