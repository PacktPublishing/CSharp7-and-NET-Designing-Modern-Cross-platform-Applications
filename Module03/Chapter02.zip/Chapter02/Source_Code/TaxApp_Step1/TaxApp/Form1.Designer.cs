﻿namespace TaxApp
{
    partial class TaxCalcForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Sextxt = new System.Windows.Forms.TextBox();
            this.Agetxt = new System.Windows.Forms.TextBox();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.Locationtxt = new System.Windows.Forms.TextBox();
            this.Idtxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.LblSex = new System.Windows.Forms.Label();
            this.LblAge = new System.Windows.Forms.Label();
            this.Labeltxt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Submitbtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.Basictxt = new System.Windows.Forms.TextBox();
            this.DAtxt = new System.Windows.Forms.TextBox();
            this.HRAtxt = new System.Windows.Forms.TextBox();
            this.AllowanceTxt = new System.Windows.Forms.TextBox();
            this.Deductionstxt = new System.Windows.Forms.TextBox();
            this.CESStxt = new System.Windows.Forms.TextBox();
            this.Liabilitytxt = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Sextxt);
            this.panel1.Controls.Add(this.Agetxt);
            this.panel1.Controls.Add(this.Nametxt);
            this.panel1.Controls.Add(this.Locationtxt);
            this.panel1.Controls.Add(this.Idtxt);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.LblSex);
            this.panel1.Controls.Add(this.LblAge);
            this.panel1.Controls.Add(this.Labeltxt);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(763, 100);
            this.panel1.TabIndex = 0;
            // 
            // Sextxt
            // 
            this.Sextxt.Location = new System.Drawing.Point(68, 75);
            this.Sextxt.Name = "Sextxt";
            this.Sextxt.Size = new System.Drawing.Size(100, 20);
            this.Sextxt.TabIndex = 4;
            // 
            // Agetxt
            // 
            this.Agetxt.Location = new System.Drawing.Point(511, 12);
            this.Agetxt.Name = "Agetxt";
            this.Agetxt.Size = new System.Drawing.Size(100, 20);
            this.Agetxt.TabIndex = 3;
            // 
            // Nametxt
            // 
            this.Nametxt.Location = new System.Drawing.Point(284, 16);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(100, 20);
            this.Nametxt.TabIndex = 2;
            // 
            // Locationtxt
            // 
            this.Locationtxt.Location = new System.Drawing.Point(284, 72);
            this.Locationtxt.Name = "Locationtxt";
            this.Locationtxt.Size = new System.Drawing.Size(100, 20);
            this.Locationtxt.TabIndex = 5;
            // 
            // Idtxt
            // 
            this.Idtxt.Location = new System.Drawing.Point(62, 19);
            this.Idtxt.Name = "Idtxt";
            this.Idtxt.Size = new System.Drawing.Size(100, 20);
            this.Idtxt.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(219, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Location";
            // 
            // LblSex
            // 
            this.LblSex.AutoSize = true;
            this.LblSex.Location = new System.Drawing.Point(37, 82);
            this.LblSex.Name = "LblSex";
            this.LblSex.Size = new System.Drawing.Size(25, 13);
            this.LblSex.TabIndex = 5;
            this.LblSex.Text = "Sex";
            // 
            // LblAge
            // 
            this.LblAge.AutoSize = true;
            this.LblAge.Location = new System.Drawing.Point(450, 19);
            this.LblAge.Name = "LblAge";
            this.LblAge.Size = new System.Drawing.Size(26, 13);
            this.LblAge.TabIndex = 4;
            this.LblAge.Text = "Age";
            // 
            // Labeltxt
            // 
            this.Labeltxt.AutoSize = true;
            this.Labeltxt.Location = new System.Drawing.Point(219, 19);
            this.Labeltxt.Name = "Labeltxt";
            this.Labeltxt.Size = new System.Drawing.Size(35, 13);
            this.Labeltxt.TabIndex = 2;
            this.Labeltxt.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Id:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.CESStxt);
            this.panel2.Controls.Add(this.Deductionstxt);
            this.panel2.Controls.Add(this.AllowanceTxt);
            this.panel2.Controls.Add(this.HRAtxt);
            this.panel2.Controls.Add(this.DAtxt);
            this.panel2.Controls.Add(this.Basictxt);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(0, 98);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(763, 160);
            this.panel2.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(450, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Cess";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(224, 102);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Deductions";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(46, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Allowance";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Basic";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(224, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "DA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(450, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "HRA";
            // 
            // Submitbtn
            // 
            this.Submitbtn.Location = new System.Drawing.Point(66, 264);
            this.Submitbtn.Name = "Submitbtn";
            this.Submitbtn.Size = new System.Drawing.Size(107, 53);
            this.Submitbtn.TabIndex = 3;
            this.Submitbtn.Text = "Submit";
            this.Submitbtn.UseVisualStyleBackColor = true;
            this.Submitbtn.Click += new System.EventHandler(this.Submitbtn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(450, 304);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Liability";
            // 
            // Basictxt
            // 
            this.Basictxt.Location = new System.Drawing.Point(99, 33);
            this.Basictxt.Name = "Basictxt";
            this.Basictxt.Size = new System.Drawing.Size(100, 20);
            this.Basictxt.TabIndex = 3;
            // 
            // DAtxt
            // 
            this.DAtxt.Location = new System.Drawing.Point(284, 37);
            this.DAtxt.Name = "DAtxt";
            this.DAtxt.Size = new System.Drawing.Size(100, 20);
            this.DAtxt.TabIndex = 1;
            // 
            // HRAtxt
            // 
            this.HRAtxt.Location = new System.Drawing.Point(511, 37);
            this.HRAtxt.Name = "HRAtxt";
            this.HRAtxt.Size = new System.Drawing.Size(100, 20);
            this.HRAtxt.TabIndex = 2;
            // 
            // AllowanceTxt
            // 
            this.AllowanceTxt.Location = new System.Drawing.Point(108, 95);
            this.AllowanceTxt.Name = "AllowanceTxt";
            this.AllowanceTxt.Size = new System.Drawing.Size(100, 20);
            this.AllowanceTxt.TabIndex = 4;
            // 
            // Deductionstxt
            // 
            this.Deductionstxt.Location = new System.Drawing.Point(311, 102);
            this.Deductionstxt.Name = "Deductionstxt";
            this.Deductionstxt.Size = new System.Drawing.Size(100, 20);
            this.Deductionstxt.TabIndex = 5;
            // 
            // CESStxt
            // 
            this.CESStxt.Location = new System.Drawing.Point(511, 99);
            this.CESStxt.Name = "CESStxt";
            this.CESStxt.Size = new System.Drawing.Size(100, 20);
            this.CESStxt.TabIndex = 6;
            // 
            // Liabilitytxt
            // 
            this.Liabilitytxt.Location = new System.Drawing.Point(511, 301);
            this.Liabilitytxt.Name = "Liabilitytxt";
            this.Liabilitytxt.Size = new System.Drawing.Size(100, 20);
            this.Liabilitytxt.TabIndex = 4;
            // 
            // TaxCalcForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 345);
            this.Controls.Add(this.Liabilitytxt);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Submitbtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "TaxCalcForm";
            this.Text = "TaxCalc";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Sextxt;
        private System.Windows.Forms.TextBox Agetxt;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox Locationtxt;
        private System.Windows.Forms.TextBox Idtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LblSex;
        private System.Windows.Forms.Label LblAge;
        private System.Windows.Forms.Label Labeltxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Submitbtn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox CESStxt;
        private System.Windows.Forms.TextBox Deductionstxt;
        private System.Windows.Forms.TextBox AllowanceTxt;
        private System.Windows.Forms.TextBox HRAtxt;
        private System.Windows.Forms.TextBox DAtxt;
        private System.Windows.Forms.TextBox Basictxt;
        private System.Windows.Forms.TextBox Liabilitytxt;
    }
}

